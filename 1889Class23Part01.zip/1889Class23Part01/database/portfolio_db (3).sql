-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 06, 2022 at 10:45 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `portfolio_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `banners`
--

CREATE TABLE `banners` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `sub_title` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `image` varchar(100) NOT NULL,
  `active_status` tinyint(2) NOT NULL DEFAULT 1 COMMENT '0=InActive, 1=Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `banners`
--

INSERT INTO `banners` (`id`, `title`, `sub_title`, `details`, `image`, `active_status`) VALUES
(33, 'Title updated', 'subtitle', 'details here', 'img1656769990_1906979566.jpg', 1),
(34, 'Another Title', 'Another subtitle', 'details another', 'img1656770881_6018876175.png', 1),
(35, 'New title updated', 'New subtitle', 'new details', 'img1656770858_8765078516.png', 1),
(36, 'Learn with Fazlay', 'Learn from Home', 'lorem ipsum', 'img1656771141_1617541617.png', 1),
(37, 'This is a new title', 'new subtilte', 'new details', 'img1656833831_3366118583.png', 0);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `active_status` tinyint(2) NOT NULL DEFAULT 1 COMMENT '1=Active and 0=Inactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_name`, `active_status`) VALUES
(1, 'Web development', 0),
(2, 'Wordpress Development', 0),
(3, 'Wordpress Development Pro', 0),
(4, 'Graphics Design', 1),
(5, 'Android Develop', 0),
(6, 'Android Apps Developement', 1),
(7, 'Theme Development', 0),
(8, 'Wordpress Theme Development', 1);

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `project_name` varchar(255) NOT NULL,
  `project_link` varchar(255) DEFAULT NULL,
  `project_image` varchar(100) NOT NULL,
  `active_status` tinyint(2) NOT NULL DEFAULT 1 COMMENT '1=Active and 0=Inactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `category_id`, `project_name`, `project_link`, `project_image`, `active_status`) VALUES
(9, 4, '3D Graphics', 'developerfazlay.com', 'img1656846876_6666178854.png', 0),
(10, 6, 'Android Apps Develop', 'http://developerfazlay.com/', 'img1656846921_1186542669.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sections`
--

CREATE TABLE `sections` (
  `id` int(11) NOT NULL,
  `section_title` varchar(255) NOT NULL,
  `section_subtitle` varchar(255) NOT NULL,
  `section_details` text NOT NULL,
  `section_page_no` tinyint(2) NOT NULL,
  `active_status` tinyint(2) NOT NULL DEFAULT 1 COMMENT '1=active 0=inactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sections`
--

INSERT INTO `sections` (`id`, `section_title`, `section_subtitle`, `section_details`, `section_page_no`, `active_status`) VALUES
(1, 'First Section updated', 'First Section', 'First Sectiondetails', 1, 0),
(2, 'New section up', 'New section up', 'New section upNew sectionNew sectionnew details', 2, 0),
(3, 'Another section', 'subtitle', 'details', 4, 1),
(4, 'About us section', 'about us subtitle', 'details for about us', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `service_name` varchar(255) NOT NULL,
  `service_details` text NOT NULL,
  `service_link` varchar(255) NOT NULL,
  `service_icon` varchar(50) DEFAULT NULL,
  `service_type` tinyint(2) NOT NULL DEFAULT 1 COMMENT '1=default left 2 =right service ',
  `active_status` tinyint(2) NOT NULL DEFAULT 1 COMMENT '1=active 0= inactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `service_name`, `service_details`, `service_link`, `service_icon`, `service_type`, `active_status`) VALUES
(1, 'updated service', 'Service details update', 'http://developerfazlay.com', 'fa fa-home', 2, 1),
(3, 'Aresh khan', 'fun', 'developerfazlay.com', 'fa fa-google', 2, 0),
(4, 'Another service', 'another details', '#', 'fa fa-email', 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `banners`
--
ALTER TABLE `banners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sections`
--
ALTER TABLE `sections`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `banners`
--
ALTER TABLE `banners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `sections`
--
ALTER TABLE `sections`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
